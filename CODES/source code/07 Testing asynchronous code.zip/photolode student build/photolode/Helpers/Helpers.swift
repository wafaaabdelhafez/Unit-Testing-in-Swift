//
//  Helpers.swift
//  photolode
//
//  Created by Caleb Stultz on 1/5/18.
//  Copyright © 2018 Caleb Stultz. All rights reserved.
//

import Foundation

var imageURLStrings = ["https://images.pexels.com/photos/768562/pexels-photo-768562.jpeg", "https://images.pexels.com/photos/675685/pexels-photo-675685.jpeg", "https://images.pexels.com/photos/722218/pexels-photo-722218.jpeg", "https://images.pexels.com/photos/768218/pexels-photo-768218.jpeg", "https://images.pexels.com/photos/773804/pexels-photo-773804.jpeg", "https://images.pexels.com/photos/772662/pexels-photo-772662.jpeg", "https://images.pexels.com/photos/767084/pexels-photo-767084.jpeg", "https://images.pexels.com/photos/768898/pexels-photo-768898.jpeg", "https://images.pexels.com/photos/769153/pexels-photo-769153.jpeg", "https://images.pexels.com/photos/765577/pexels-photo-765577.jpeg"]
