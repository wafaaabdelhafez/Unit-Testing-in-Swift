//
//  Operand.swift
//  wallcalcaroni
//
//  Created by Caleb Stultz on 1/4/18.
//  Copyright © 2018 Caleb Stultz. All rights reserved.
//

import Foundation

enum Operand: Int {
    case add = 1
    case subtract = 2
    case multiply = 3
    case divide = 4
}
